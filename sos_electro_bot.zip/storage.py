"""Простое хранилище статистики в памяти."""

from datetime import datetime
from collections import defaultdict

_users: set[int] = set()
_requests: list[dict] = []


def record_user(user_id: int, username: str | None = None) -> None:
    _users.add(user_id)
    _requests.append({
        "user_id": user_id,
        "username": username,
        "time": datetime.now().isoformat(),
    })


def get_stats() -> dict:
    return {
        "total_users": len(_users),
        "total_requests": len(_requests),
        "users": list(_users),
    }
